#ifndef TESTS_H
#define TESTS_H

bool testMobile1();
bool testMobile2();

bool testSimulation1();
bool testSimulation2();
bool testSimulation3();
bool testSimulation4();

bool testVecteur3D();

bool testTerre();

bool testSatellite1();
bool testSatellite2();
bool testLune();

#endif
